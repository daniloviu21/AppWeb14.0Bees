import { Component } from '@angular/core';

@Component({
  selector: 'app-client-page',
  standalone: false,
  
  templateUrl: './client-page.component.html',
  styleUrl: './client-page.component.css'
})
export class ClientPageComponent {

}
